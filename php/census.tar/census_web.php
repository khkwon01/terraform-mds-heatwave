<!DOCTYPE HTML>  
  <html>
  <head>
  <style>
    .error {color: #FF0000;}
  </style>
  </head>
  <body>  
  <h2>Machine Learning Demo - Task classification using the census Dataset </h2>
  <img class="img-responsive" src="images/Census-bureau.png" alt="census_dataset" window=1000 height=400> 
  <h4>Example:</h4>
  <?php
  echo '<pre>';
  echo '<p><font color=blue>revenue<=50K ->     </font>sepal length: 5.0   sepal width": 2.3   petal length: 3.3  petal width:1.0</p>';
  echo '<p><font color=blue>revenue>50K  ->     </font>sepal length: 5.0   sepal width": 2.3   petal length: 3.3  petal width:1.0</p>';
  echo '</pre>';
  ?>
  <h3>Enter the following information:</h3>

  <p><span class="error">* required field</span></p>
  <form method="post" action="<?php $_SERVER["PHP_SELF"];?>"> 
    <span style="padding-left: 2px;"> Sepal Length: <span style="padding-left: 2px;"> <input type="number" min="0" max="10" step="0.1" name="sepal_l" value="<?php echo $sepal_l;?>" >
    <span class="error">* <?php echo $sepal_lErr;?></span>
    <br><br>
    <span style="padding-left: 2px;"> Sepal Width: <span style="padding-left: 8px;"> <input type="number" min="0" max="10" step="0.1" name="sepal_w" value="<?php echo $sepal_w;?>">
    <span class="error">* <?php echo $sepal_wErr;?></span>
    <br><br>
    <span style="padding-left: 2px;"> Petal Length: <span style="padding-left: 6px;"> <input type="number" min="0" max="10" step="0.1" name="petal_l" value="<?php echo $petal_l;?>">
    <span class="error">* <?php echo $petal_lErr;?></span>
    <br><br>
    <span style="padding-left: 2px;">Petal Width: <span style="padding-left: 10px;"> <input type="number" min="0" max="10" step="0.1" name="petal_w" value="<?php echo $petal_w;?>">
    <span class="error">* <?php echo $petal_wErr;?></span>
    <br><br>
    <input type="submit" name="submit" value="Submit">  
  </form>
  <?php

    if($petal_l !="" && $petal_w !="" && $sepal_l !="" && $sepal_w !=""){
      $iris_model = load_model($link); 
      use_model($link,$iris_model,$petal_l,$petal_w,$sepal_l,$sepal_w);
    }
  ?> 
</body>
</html>
