
<?php
phpinfo();
?>

