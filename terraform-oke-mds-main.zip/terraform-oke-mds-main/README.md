# terraform-oke-mds

Provision Oracle Container Engine for Kubernetes (OKE) and MySQL Database Service (MDS) with Terraform.

[![Deploy to Oracle Cloud](https://oci-resourcemanager-plugin.plugins.oci.oraclecloud.com/latest/deploy-to-oracle-cloud.svg)](https://cloud.oracle.com/resourcemanager/stacks/create?zipUrl=https://github.com/rayeswong/terraform-oke-mds/archive/refs/tags/heatwave.zip)